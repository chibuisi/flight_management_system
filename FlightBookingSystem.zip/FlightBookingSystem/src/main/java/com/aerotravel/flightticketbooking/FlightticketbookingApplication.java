package com.aerotravel.flightticketbooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class FlightticketbookingApplication {

    public static void main(String[] args) {
        SpringApplication.run(FlightticketbookingApplication.class, args);
    }

}
