# FlightBookingSystem
Booking flight ticket system written by java

1- Framework: Spring Boot
2- Database: MySQL

Hibernate, Thymeleaf, Spring Boot Security, Thymeleaf Dialect, JPA
